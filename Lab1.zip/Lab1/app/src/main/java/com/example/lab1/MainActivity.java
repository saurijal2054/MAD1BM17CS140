package com.example.lab1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    TextView tv;
    Button b1,b2;
    int ch = 0;
    float d = 30;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (TextView)findViewById(R.id.txtview);
        b1 = (Button)findViewById(R.id.chncolor);
        b2 = (Button)findViewById(R.id.chnfont);
    }
    public void changeColor(View v){
        switch (ch){
            case 0 : tv.setTextColor(Color.RED);break;
            case 1 : tv.setTextColor(Color.GREEN);break;
            case 2 : tv.setTextColor(Color.BLUE);break;
            case 3 : tv.setTextColor(Color.DKGRAY);break;
        }
        ch++;
        if(ch == 4) ch = 0;
    }
    public void changeFont(View v){
        tv.setTextSize(d);
        d += 5;
        if(d == 100) d = 30;
    }
}
