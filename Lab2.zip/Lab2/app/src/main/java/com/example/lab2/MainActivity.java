package com.example.lab2;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;


public class MainActivity extends AppCompatActivity {
    EditText et1,et2;
    Spinner sp;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = (EditText)findViewById(R.id.editText);
        et2 = (EditText)findViewById(R.id.editText2);
        sp = (Spinner)findViewById(R.id.spinner);
        b = (Button)findViewById(R.id.button);
        String[] dept = {"CSE","ISE","Mech","Civil"};
        ArrayAdapter arrayAdapter = new ArrayAdapter(MainActivity.this,R.layout.support_simple_spinner_dropdown_item,dept);
        sp.setAdapter(arrayAdapter);
    }
    public void onClick(View view){
        String name = et1.getText().toString();
        String usn = et2.getText().toString();
        String dept = sp.getSelectedItem().toString();
        Intent i = new Intent(MainActivity.this, Main2Activity.class);
        i.putExtra("name",name);
        i.putExtra("usn",usn);
        i.putExtra("dept",dept);
        startActivity(i);
    }
}
