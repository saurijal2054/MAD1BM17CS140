package com.example.lab2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView tv4,tv5,tv6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        tv4 = (TextView)findViewById(R.id.textView4);
        tv5 = (TextView)findViewById(R.id.textView5);
        tv6 = (TextView)findViewById(R.id.textView6);
        Intent i = getIntent();
        String name = i.getStringExtra("name");
        String usn = i.getStringExtra("usn");
        String dept = i.getStringExtra("dept");
        tv4.setText("NAME:" + name);
        tv5.setText("USN:"+usn);
        tv6.setText("DEPT:" + dept);
    }
}
